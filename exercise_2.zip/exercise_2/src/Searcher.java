import org.apache.log4j.Logger;

import java.io.File;
import java.util.Scanner;

public class Searcher {
    public static void main(String[] args) {

        final Logger logger = Logger.getLogger(Searcher.class);
        final Scanner scanner = new Scanner(System.in);
        final  File file = new File("/home/david/IdeaProjects/exercise_2/folder");

        if (!file.isDirectory()) {
            throw new IllegalStateException("ხო არ ხაკერობ რამეს?!");
        }

        System.out.println("შეიყვანეთ ტექსტი: ");
        String keyword = scanner.nextLine();

        logger.info("შემოტანილი სიტყვაა : " + keyword);

        for (File file_1 : file.listFiles()) {
            if (file_1.getName().startsWith(keyword)) {
                logger.info("მოიძებნა => " + file_1.getName());
            }
        }
    }
}
